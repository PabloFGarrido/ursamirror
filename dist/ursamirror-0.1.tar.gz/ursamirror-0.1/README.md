# ursamirror

[![PyPI - Version](https://img.shields.io/pypi/v/ursamirror.svg)](https://pypi.org/project/ursamirror)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/ursamirror.svg)](https://pypi.org/project/ursamirror)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install ursamirror
```

## License

`ursamirror` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
