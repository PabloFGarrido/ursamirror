# SPDX-FileCopyrightText: 2024-present Pablo F. Garrido <f.garrido.pablo@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
